/// <reference types="vite/client" />

declare interface Window {
  Razorpay: any;
}
